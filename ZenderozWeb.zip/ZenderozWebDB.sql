CREATE DATABASE  IF NOT EXISTS `zenderozwebdb` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `zenderozwebdb`;
-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: zenderozwebdb
-- ------------------------------------------------------
-- Server version	5.7.12-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bus`
--

DROP TABLE IF EXISTS `bus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bus` (
  `idBus` int(11) NOT NULL AUTO_INCREMENT,
  `Route_idRoute` int(11) DEFAULT NULL,
  `Name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idBus`),
  KEY `fk_Bus_Route_idx` (`Route_idRoute`),
  CONSTRAINT `fk_Bus_Route` FOREIGN KEY (`Route_idRoute`) REFERENCES `route` (`idRoute`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bus`
--

LOCK TABLES `bus` WRITE;
/*!40000 ALTER TABLE `bus` DISABLE KEYS */;
INSERT INTO `bus` VALUES (1,1,'Bus 1'),(2,1,'Bus 2'),(3,1,'Bus 3'),(4,1,'Bus 4');
/*!40000 ALTER TABLE `bus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `route`
--

DROP TABLE IF EXISTS `route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `route` (
  `idRoute` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `ReturnStop` int(11) DEFAULT NULL,
  PRIMARY KEY (`idRoute`),
  KEY `fk_Route_Stop1_idx` (`ReturnStop`),
  CONSTRAINT `fk_Route_Stop1` FOREIGN KEY (`ReturnStop`) REFERENCES `stop` (`idStop`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `route`
--

LOCK TABLES `route` WRITE;
/*!40000 ALTER TABLE `route` DISABLE KEYS */;
INSERT INTO `route` VALUES (1,'Km. 4 - Circunvalación 2 - Estación El Varillal - HUM',19);
/*!40000 ALTER TABLE `route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `route_stop`
--

DROP TABLE IF EXISTS `route_stop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `route_stop` (
  `Route_idRoute` int(11) NOT NULL,
  `Stop_idStop` int(11) NOT NULL,
  `Order` int(10) unsigned NOT NULL,
  `Distance` int(10) unsigned NOT NULL,
  PRIMARY KEY (`Route_idRoute`,`Stop_idStop`),
  KEY `fk_Route_has_Stop_Stop1_idx` (`Stop_idStop`),
  KEY `fk_Route_has_Stop_Route1_idx` (`Route_idRoute`),
  CONSTRAINT `fk_Route_has_Stop_Route1` FOREIGN KEY (`Route_idRoute`) REFERENCES `route` (`idRoute`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Route_has_Stop_Stop1` FOREIGN KEY (`Stop_idStop`) REFERENCES `stop` (`idStop`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `route_stop`
--

LOCK TABLES `route_stop` WRITE;
/*!40000 ALTER TABLE `route_stop` DISABLE KEYS */;
INSERT INTO `route_stop` VALUES (1,1,1,0),(1,2,2,350),(1,3,3,350),(1,4,4,600),(1,5,5,600),(1,6,6,300),(1,7,7,500),(1,8,8,180),(1,9,9,1700),(1,10,10,1000),(1,11,11,400),(1,12,12,550),(1,13,13,230),(1,14,14,550),(1,15,15,600),(1,16,16,400),(1,17,17,400),(1,18,18,1400),(1,19,19,2700),(1,20,20,400),(1,21,21,400),(1,22,22,600),(1,23,23,550),(1,24,24,230),(1,25,25,550),(1,26,26,400),(1,27,27,1000),(1,28,28,1700),(1,29,29,180),(1,30,30,500),(1,31,31,300),(1,32,32,600),(1,33,33,600),(1,34,34,350),(1,35,35,350),(1,36,36,350);
/*!40000 ALTER TABLE `route_stop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `route_stops_view`
--

DROP TABLE IF EXISTS `route_stops_view`;
/*!50001 DROP VIEW IF EXISTS `route_stops_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `route_stops_view` AS SELECT 
 1 AS `idRoute`,
 1 AS `idStop`,
 1 AS `Name`,
 1 AS `Order`,
 1 AS `Distance`,
 1 AS `Lat`,
 1 AS `Lng`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `stop`
--

DROP TABLE IF EXISTS `stop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stop` (
  `idStop` int(11) NOT NULL AUTO_INCREMENT,
  `Lat` decimal(9,6) NOT NULL,
  `Lng` decimal(9,6) NOT NULL,
  `Name` varchar(45) NOT NULL,
  PRIMARY KEY (`idStop`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stop`
--

LOCK TABLES `stop` WRITE;
/*!40000 ALTER TABLE `stop` DISABLE KEYS */;
INSERT INTO `stop` VALUES (1,10.671299,-71.630052,'Hospital Universitario'),(2,10.669771,-71.632368,'Medicina'),(3,10.667631,-71.634814,'Ipsfa'),(4,10.664783,-71.637726,'Urbanización Sucre'),(5,10.664276,-71.641572,'Sistema Regional'),(6,10.665302,-71.643551,'El Reloj'),(7,10.668098,-71.647391,'Cementerio I'),(8,10.669036,-71.648700,'Cementerio II'),(9,10.660971,-71.654339,'Amparo'),(10,10.652766,-71.658776,'Cumbres de Maracaibo'),(11,10.649877,-71.661107,'Valle Alto'),(12,10.645508,-71.663651,'Hospital Madre Rafols'),(13,10.643458,-71.663865,'C-2'),(14,10.638493,-71.663952,'El Turf'),(15,10.633124,-71.664063,'Ogaret'),(16,10.629524,-71.664138,'Barrio Bolivar'),(17,10.625889,-71.664196,'El Tránsito'),(18,10.623505,-71.659519,'Estación El Varillal Sur'),(19,10.623724,-71.659761,'Estación El Varillal Norte'),(20,10.625889,-71.664196,'El Tránsito'),(21,10.629524,-71.664138,'Barrio Bolivar'),(22,10.633124,-71.664063,'Ogaret'),(23,10.638493,-71.663952,'El Turf'),(24,10.643458,-71.663865,'C-2'),(25,10.645508,-71.663651,'Hospital Madre Rafols'),(26,10.649877,-71.661107,'Valle Alto'),(27,10.652766,-71.658776,'Cumbres de Maracaibo'),(28,10.660971,-71.654339,'Amparo'),(29,10.669036,-71.648700,'Cementerio II'),(30,10.668098,-71.647391,'Cementerio I'),(31,10.665302,-71.643551,'El Reloj'),(32,10.664276,-71.641572,'Sistema Regional'),(33,10.664783,-71.637726,'Urbanización Sucre'),(34,10.667631,-71.634814,'Ipsfa'),(35,10.669771,-71.632368,'Medicina'),(36,10.671299,-71.630052,'Hospital Universitario');
/*!40000 ALTER TABLE `stop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `route_stops_view`
--

/*!50001 DROP VIEW IF EXISTS `route_stops_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `route_stops_view` AS select `rs`.`Route_idRoute` AS `idRoute`,`stop`.`idStop` AS `idStop`,`stop`.`Name` AS `Name`,`rs`.`Order` AS `Order`,`rs`.`Distance` AS `Distance`,`stop`.`Lat` AS `Lat`,`stop`.`Lng` AS `Lng` from (`route_stop` `rs` join `stop` on((`rs`.`Stop_idStop` = `stop`.`idStop`))) order by `rs`.`Order` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-06-28 23:49:26
